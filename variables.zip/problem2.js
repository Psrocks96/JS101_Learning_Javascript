let name = "Parmod Kumar";
console.log(name);
name="Hariram Sharma";
console.log(name);
name="Kamlesh Devi";
console.log(name);
