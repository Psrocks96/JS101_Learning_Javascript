let name="Parmod Kumar";
let age=26;
console.log(name,age);
console.log(typeof(name),  typeof(age));
