console.log("****************************");
console.log("*   Student Name:-","Parmod  *");
console.log("****************************");
console.log("*   School:- GBN School    *");
console.log("****************************");
console.log("*   Grade:- 11th           *");
console.log("****************************");
console.log("*   Section:- A            *");
console.log("****************************");
console.log("*   Roll N. 103            *");
console.log("****************************");
console.log("*   Physics:- 88           *");
console.log("****************************");
 console.log("*   Chemistry:- 92         *");
console.log("****************************");
console.log("*   Math:- 90              *")
console.log("****************************");


