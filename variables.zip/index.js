let d=3999;
let b=5000;
if (b>=d){
  console.log(b*90/100);
}else{
  console.log("Not Eligible")
}
